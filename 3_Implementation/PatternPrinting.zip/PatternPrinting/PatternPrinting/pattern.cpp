
#include <stdio.h>
#include<conio.h>
#include <stdlib.h>

int main()
{
    int i, j, rows, n, space, k = 0, count = 0, count1 = 0, count2 = 1, num = 1;
    char  alpha = 'A';

    while (1)
    {
        printf("SELECT YOUR REQUIRED PATTERN\n");
        printf("1.Half Pyramid\n2.Half pyramid of numbers\n3.Inverted half pyramid\n4.Inverted half pyramid of numbers\n5.Full pyramid\n6.Full pyramid of numbers\n7.Inverted full pyramid\n8.Rhombus\n9.Pascal's triangle\n10.Floyd's triangle\n0.Exit\n");
        scanf("%d", &n);

        if (0 == n)
            exit(0);

        printf("Enter the number of rows: ");
        scanf("%d", &rows);

        switch (n)
        {
        case 1:
        {

            for (i = 1; i <= rows; ++i)
            {
                for (j = 1; j <= i; ++j)
                {
                    printf("* ");

                }
                printf("\n");
            }
            break;
        }
        case 2:
        {

            for (i = 1; i <= rows; ++i)
            {
                for (j = 1; j <= i; ++j)
                {
                    printf("%d ", j);
                }
                printf("\n");
            }
            break;
        }

        case 3:
        {

            for (i = rows; i >= 1; --i)
            {
                for (j = 1; j <= i; ++j)
                {
                    printf("* ");
                }
                printf("\n");
            }
            break;
        }
        case 4:
        {

            for (i = rows; i >= 1; --i)
            {
                for (j = 1; j <= i; ++j)
                {
                    printf("%d ", j);
                }
                printf("\n");
            }
            break;
        }
        case 5:
        {

            for (i = 1; i <= rows; ++i, k = 0)
            {
                for (space = 1; space <= rows - i; ++space)
                {
                    printf("  ");
                }
                while (k != 2 * i - 1)
                {
                    printf("* ");
                    ++k;
                }
                printf("\n");

            }
            break;
        }
        case 6:
        {

            for (i = 1; i <= rows; ++i)
            {
                for (space = 1; space <= rows - i; ++space)
                {
                    printf("  ");
                    ++count;
                }
                while (k != 2 * i - 1)
                {
                    if (count <= rows - 1)
                    {
                        printf("%d ", i + k);
                        ++count;
                    }
                    else
                    {
                        ++count1;
                        printf("%d ", (i + k - 2 * count1));

                    }
                    ++k;
                }
                count1 = count = k = 0;
                printf("\n");
            }
            break;
        }
        case 7:
        {

            for (i = rows; i >= 1; --i)
            {
                for (space = 0; space < rows - i; ++space)
                    printf("  ");
                for (j = i; j <= 2 * i - 1; ++j)
                    printf("* ");
                for (j = 0; j < i - 1; ++j)
                    printf("* ");
                printf("\n");
            }
            break;
        }
        case 8:
        {

            for (i = 1; i < rows; ++i, k = 0)
            {
                for (space = 1; space <= rows - i; ++space)
                {
                    printf("  ");
                }
                while (k != 2 * i - 1)
                {
                    printf("* ");
                    ++k;
                }
                printf("\n");
            }
            for (i = rows; i >= 1; --i)
            {
                for (space = 0; space < rows - i; ++space)
                    printf("  ");
                for (j = i; j <= 2 * i - 1; ++j)
                    printf("* ");
                for (j = 0; j < i - 1; ++j)
                    printf("* ");
                printf("\n");
            }
            break;
        }
        case 9:
        {

            for (i = 0; i < rows; i++)
            {
                for (space = 1; space <= rows - i; space++)
                    printf("  ");
                for (j = 0; j <= i; j++)
                {
                    if (j == 0 || i == 0)
                    {
                        count2 = 1;
                    }
                    else
                    {
                        count2 = count2 * (i - j + 1) / j;
                        printf("%4d", count2);
                    }
                }
                printf("\n");
            }
            break;
        }
        case 10:
        {

            for (i = 1; i <= rows; i++)
            {
                for (j = 1; j <= i; ++j)
                {
                    printf("%d ", num);
                    ++num;

                }
                printf("\n");
            }
            break;
        }

        default:
        {
            printf("Enter a valid number");
        }


        }

    }
    return 0;
}


